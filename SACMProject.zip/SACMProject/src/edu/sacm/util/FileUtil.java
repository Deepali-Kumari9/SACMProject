package edu.sacm.util;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;

public class FileUtil {

    
    public static void backupDirectory(Path sourceDir, Path backupRoot) throws IOException {
        if (!Files.exists(sourceDir)) {
            throw new IllegalArgumentException("Source does not exist: " + sourceDir);
        }
        String ts = java.time.LocalDateTime.now().toString().replace(":", "-");
        Path dest = backupRoot.resolve("backup-" + ts);
        Files.createDirectories(dest);

        Files.walkFileTree(sourceDir, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
                Path target = dest.resolve(sourceDir.relativize(dir));
                if (!Files.exists(target)) Files.createDirectory(target);
                return FileVisitResult.CONTINUE;
            }
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                Files.copy(file, dest.resolve(sourceDir.relativize(file)), StandardCopyOption.REPLACE_EXISTING);
                return FileVisitResult.CONTINUE;
            }
        });
        System.out.println("Backup created at: " + dest.toAbsolutePath());
    }

    
    public static long computeDirectorySize(Path dir) throws IOException {
        final long[] size = {0};
        Files.walkFileTree(dir, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                size[0] += attrs.size();
                return FileVisitResult.CONTINUE;
            }
        });
        return size[0];
    }
}
