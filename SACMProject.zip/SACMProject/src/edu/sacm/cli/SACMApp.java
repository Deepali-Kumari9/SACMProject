package edu.sacm.cli;

import edu.sacm.config.AppConfig;
import edu.sacm.domain.*;
import edu.sacm.exceptions.DuplicateEnrollmentException;
import edu.sacm.exceptions.MaxCreditLimitExceededException;
import edu.sacm.service.*;
import edu.sacm.util.FileUtil;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class SACMApp {
    public static void main(String[] args) {
      
        AppConfig config = AppConfig.getInstance();

        
        StudentService studentService = new StudentService();
        CourseService courseService = new CourseService(config); 
        EnrollmentService enrollmentService = new EnrollmentService(courseService, studentService);
        TranscriptService transcriptService = new TranscriptService(enrollmentService, courseService);

        Scanner sc = new Scanner(System.in);
        System.out.println("==== Welcome to Campus Course & Records Manager (CCRM) ====");

        while (true) {
            System.out.println("\n--- Main Menu ---");
            System.out.println("1. Manage Students");
            System.out.println("2. Manage Courses");
            System.out.println("3. Enrollment / Grades");
            System.out.println("4. Export / Backup (demo)");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                case 1 -> manageStudents(sc, studentService);
                case 2 -> manageCourses(sc, courseService);
                case 3 -> manageEnrollment(sc, enrollmentService, transcriptService);
                case 4 -> runBackupDemo();
                case 5 -> {
                    System.out.println("👋 Thank you. Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    private static void manageStudents(Scanner sc, StudentService ss) {
        System.out.println("--- Students ---");
        System.out.println("1. Add Student");
        System.out.println("2. List Students");
        System.out.print("Choice: ");
        int c = sc.nextInt();
        sc.nextLine();
        if (c == 1) {
            System.out.print("RegNo: ");
            String reg = sc.nextLine();
            System.out.print("Name: ");
            String name = sc.nextLine();
            System.out.print("Email: ");
            String email = sc.nextLine();
            Student s = new Student("S" + reg, reg, name, email);
            ss.addStudent(s);
            System.out.println("Student added.");
        } else if (c == 2) {
            ss.listStudents();
        }
    }

    private static void manageCourses(Scanner sc, CourseService cs) {
        System.out.println("--- Courses ---");
        System.out.println("1. Add Course");
        System.out.println("2. List Courses");
        System.out.print("Choice: ");
        int c = sc.nextInt();
        sc.nextLine();
        if (c == 1) {
            System.out.print("Code: ");
            String code = sc.nextLine();
            System.out.print("Title: ");
            String title = sc.nextLine();
            System.out.print("Credits: ");
            int credits = sc.nextInt();
            sc.nextLine();
            System.out.print("Instructor name: ");
            String instr = sc.nextLine();
            System.out.print("Department: ");
            String dept = sc.nextLine();
            Course course = new Course.Builder(code)
                    .title(title).credits(credits).instructor(instr)
                    .department(dept).build();
            cs.addCourse(course);
            System.out.println("Course added.");
        } else if (c == 2) {
            cs.listCourses();
        }
    }

    private static void manageEnrollment(Scanner sc, EnrollmentService es, TranscriptService ts) {
        System.out.println("----Enrollment/Grades ----");
        System.out.println("1. Enroll student");
        System.out.println("2. Assign grade");
        System.out.println("3. Print transcript");
        System.out.print("Choice: ");
        int c = sc.nextInt();
        sc.nextLine();
        try {
            if (c == 1) {
                System.out.print("Student RegNo: ");
                String reg = sc.nextLine();
                System.out.print("Course Code: ");
                String code = sc.nextLine();
                es.enroll(reg, code);
                System.out.println("Enrolled successfully.");
            } else if (c == 2) {
                System.out.print("Student RegNo: ");
                String reg = sc.nextLine();
                System.out.print("Course Code: ");
                String code = sc.nextLine();
                System.out.print("Grade (S,A,B,C,D,F): ");
                String g = sc.nextLine();
                es.assignGrade(reg, code, Grade.valueOf(g));
                System.out.println("Grade assigned.");
            } else if (c == 3) {
                System.out.print("Student RegNo: ");
                String reg = sc.nextLine();
                ts.printTranscript(reg);
            }
        } catch (DuplicateEnrollmentException | MaxCreditLimitExceededException ex) {
            System.out.println("Business rule violated: " + ex.getMessage());
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private static void runBackupDemo() {
        try {
            Path src = Paths.get("data"); 
            Path root = Paths.get("backups");
            FileUtil.backupDirectory(src, root);
            long size = FileUtil.computeDirectorySize(root);
            System.out.println("Total backup size (bytes): " + size);
        } catch (Exception e) {
            System.out.println("Backup error: " + e.getMessage());
        }
    }
}