package edu.sacm.service;

import edu.sacm.config.AppConfig; 
import edu.sacm.domain.Course;
import edu.sacm.domain.Semester;
import java.util.*;
import java.util.stream.Collectors;

public class CourseService {
    private final Map<String, Course> courses = new HashMap<>();

    
    public CourseService(AppConfig config) {
        
    }

    public void addCourse(Course c) {
        courses.put(c.getCode(), c);
    }

    public void listCourses() {
        if (courses.isEmpty()) {
            System.out.println("No courses available.");
        } else {
            courses.values().forEach(System.out::println);
        }
    }

    public Course findCourseByCode(String code) {
        return courses.get(code);
    }

    
    public List<Course> searchByInstructor(String instr) {
        return courses.values().stream()
                .filter(c -> c.getInstructor().equalsIgnoreCase(instr))
                .collect(Collectors.toList());
    }

    
    public List<Course> filterByDepartment(String dept) {
        return courses.values().stream()
                .filter(c -> c.getDepartment().equalsIgnoreCase(dept))
                .collect(Collectors.toList());
    }

    
    public List<Course> filterBySemester(Semester sem) {
        return courses.values().stream()
                .filter(c -> c.getSemester() == sem)
                .collect(Collectors.toList());
    }
}