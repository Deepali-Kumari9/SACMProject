package edu.sacm.service;

import edu.sacm.domain.Enrollment;
import edu.sacm.domain.Student;
import edu.sacm.domain.Course;
import edu.sacm.domain.Grade;
import edu.sacm.exceptions.DuplicateEnrollmentException;
import edu.sacm.exceptions.MaxCreditLimitExceededException;

import java.util.*;

public class EnrollmentService {
    private final Map<String, List<Enrollment>> enrollments = new HashMap<>();
    private final CourseService courseService;
    private final StudentService studentService;
    private final int MAX_CREDITS_PER_SEM = 24;

    public EnrollmentService(CourseService cs, StudentService ss) {
        this.courseService = cs;
        this.studentService = ss;
    }

    public void enroll(String regNo, String courseCode) throws DuplicateEnrollmentException, MaxCreditLimitExceededException {
        Student s = studentService.findStudentByRegNo(regNo);
        Course c = courseService.findCourseByCode(courseCode);
        if (s == null || c == null) {
            throw new IllegalArgumentException("Student or Course not found.");
        }

        List<Enrollment> list = enrollments.computeIfAbsent(regNo, _ -> new ArrayList<>());

        boolean already = list.stream().anyMatch(e -> e.getCourseCode().equals(courseCode));
        if (already) throw new DuplicateEnrollmentException("Student already enrolled in " + courseCode);

        int currentCredits = list.stream()
                .map(e -> courseService.findCourseByCode(e.getCourseCode()))
                .filter(Objects::nonNull)
                .mapToInt(Course::getCredits).sum();

        if (currentCredits + c.getCredits() > MAX_CREDITS_PER_SEM) {
            throw new MaxCreditLimitExceededException("Exceeds max credits (" + MAX_CREDITS_PER_SEM + ")");
        }

        Enrollment en = new Enrollment(regNo, courseCode);
        list.add(en);
    }

    public void assignGrade(String regNo, String courseCode, Grade grade) {
        List<Enrollment> list = enrollments.get(regNo);
        if (list == null) return;
        list.stream()
            .filter(e -> e.getCourseCode().equals(courseCode))
            .findFirst()
            .ifPresent(e -> e.setGrade(grade));
    }

    public List<Enrollment> getEnrollmentsForStudent(String regNo) {
        return enrollments.getOrDefault(regNo, Collections.emptyList());
    }

    public double computeGPA(String regNo) {
        List<Enrollment> list = getEnrollmentsForStudent(regNo);
        double num = 0.0;
        int totalCredits = 0;
        for (Enrollment e : list) {
            if (e.getGrade() == null) continue;
            Course c = courseService.findCourseByCode(e.getCourseCode());
            if (c == null) continue;
            num += e.getGrade().getPoints() * c.getCredits();
            totalCredits += c.getCredits();
        }
        if (totalCredits == 0) return 0.0;
        return num / totalCredits;
    }
}
