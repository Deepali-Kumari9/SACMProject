package edu.sacm.service;

import edu.sacm.domain.Enrollment;

import java.util.List;

public class TranscriptService {
    private final EnrollmentService enrollmentService;
    private final CourseService courseService;

    public TranscriptService(EnrollmentService es, CourseService cs) {
        this.enrollmentService = es;
        this.courseService = cs;
    }

    public void printTranscript(String regNo) {
        List<Enrollment> list = enrollmentService.getEnrollmentsForStudent(regNo);
        System.out.println("=== Transcript for " + regNo + " ===");
        if (list.isEmpty()) {
            System.out.println("No enrollments found.");
            return;
        }
        list.forEach(e -> {
            System.out.println(e.toString());
            var c = courseService.findCourseByCode(e.getCourseCode());
            if (c != null) System.out.println("  Course: " + c.toString());
        });
        double gpa = enrollmentService.computeGPA(regNo);
        System.out.printf("GPA: %.2f%n", gpa);
    }
}
