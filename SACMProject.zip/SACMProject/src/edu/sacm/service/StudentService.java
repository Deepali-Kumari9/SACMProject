package edu.sacm.service;

import edu.sacm.domain.Student;
import java.util.*;

public class StudentService {
    private final Map<String, Student> students = new HashMap<>();

        public void addStudent(Student s) {
        students.put(s.getRegNo(), s);
    }

    
    public void listStudents() {
        if (students.isEmpty()) {
            System.out.println("No students available.");
        } else {
            students.values().forEach(Student::printProfile);
        }
    }

    
    public Student findStudentByRegNo(String regNo) {
        return students.get(regNo);
    }
}
