package edu.sacm.domain;

public enum Semester {
    SPRING, SUMMER, FALL
}
