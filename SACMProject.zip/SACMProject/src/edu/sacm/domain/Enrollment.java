package edu.sacm.domain;

import java.time.LocalDate;

public class Enrollment {
    private final String studentRegNo;
    private final String courseCode;
    private final LocalDate enrolledOn;
    private Grade grade;

    public Enrollment(String studentRegNo, String courseCode) {
        this.studentRegNo = studentRegNo;
        this.courseCode = courseCode;
        this.enrolledOn = LocalDate.now();
        this.grade = null;
    }

    public String getStudentRegNo() { return studentRegNo; }
    public String getCourseCode() { return courseCode; }
    public LocalDate getEnrolledOn() { return enrolledOn; }
    public Grade getGrade() { return grade; }
    public void setGrade(Grade grade) { this.grade = grade; }

    @Override
    public String toString() {
        String g = (grade == null) ? "N/A" : grade.name();
        return studentRegNo + " -> " + courseCode + " | Enrolled: " + enrolledOn + " | Grade: " + g;
    }
}
