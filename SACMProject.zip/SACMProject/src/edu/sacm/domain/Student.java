package edu.sacm.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Student extends Person {
    private String regNo;
    private boolean active;
    private LocalDate joinDate;
    private List<Course> enrolledCourses;

    public Student(String id, String regNo, String fullName, String email) {
        super(id, fullName, email);
        this.regNo = regNo;
        this.active = true;
        this.joinDate = LocalDate.now();
        this.enrolledCourses = new ArrayList<>();
    }

    public String getRegNo() {
        return regNo;
    }

    
    public LocalDate getJoinDate() {
        return joinDate;
    }

    public void enroll(Course course) {
        enrolledCourses.add(course);
    }

    @Override
    public void printProfile() {
        System.out.println("Student: " + fullName + " | RegNo: " + regNo + " | Active: " + active + " | Joined: " + joinDate);
    }

    public List<Course> getEnrolledCourses() {
        return enrolledCourses;
    }
}