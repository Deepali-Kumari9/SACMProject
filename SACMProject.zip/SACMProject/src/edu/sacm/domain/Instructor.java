package edu.sacm.domain;

public class Instructor extends Person {
    private String employeeId;
    private String department;

    public Instructor(String id, String employeeId, String fullName, String email, String department) {
        super(id, fullName, email);
        this.employeeId = employeeId;
        this.department = department;
    }

    @Override
    public void printProfile() {
        System.out.println("Instructor: " + fullName + " | EmpId: " + employeeId + " | Dept: " + department);
    }
}
